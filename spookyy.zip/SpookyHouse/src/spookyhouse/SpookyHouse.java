//********************************************************************************
// PANTHERID:  [6328062]
// CLASS: COP 2210 – [2021]
// ASSIGNMENT # [3]
// DATE: [November 4 2021]
//
// I hereby swear and affirm that this work is solely my own, and not the work 
// or the derivative of the work of someone else.
//********************************************************************************

package spookyhouse;

import javax.swing.JOptionPane;
import javax.swing.ImageIcon;

/**
 *
 * @author vrtaylor
 */
public class SpookyHouse {
    public static void main(String[] args) {
    String userName;
    String backPack;
    String item;
    String endGame;
    String startGame;
    
    spookymain userInfo = new spookymain();
    userInfo.setUserName(JOptionPane.showInputDialog( null, 
            "What is your name?"));
    ImageIcon startOfGame = new ImageIcon("spookyhouse.jpg");
    
    JOptionPane.showMessageDialog(null,"Welcome to the House of Spook, " + 
    userInfo.getName() + "!\nWe've been expecting you. Many hauntings take "
            + "place here."
    + "\nWe have entrusted you to explore the entire house. It has two floors "
    + "and many rooms.\nSince you will definitely find things "
    + "that send chills up your spine, we are giving you a backpack to provide "
    + "evidence of the hauntings here.\nHappy haunting! I mean... Hunting!\n\n"
    + "YOU RECEIVED: BACKPACK",userInfo.getName(),
    JOptionPane.INFORMATION_MESSAGE, startOfGame);
    
    
    String input = userInfo.frontDoor();
    
   if(input.equals("Living Room")){int userSelection  = userInfo.livingRoom();
        if(userSelection == 0){
                int userSelectioni  = userInfo.bathroom();
                    if(userSelectioni == 0){
                        userInfo.showerFO();
                    } else {
                        userInfo.mirrorFO();
                    }
        } else {
                userInfo.chestLR();
        }
 } else if(input.equals("Dining Room")){
      int userSelection  = userInfo.diningRoom();
                    if(userSelection == 0){
                        input = userInfo.kitchen();
                        if(input.equals("Pantry")){
                        int userSelectionii = userInfo.pantry();
                        if(userSelectionii == 0){
                            userInfo.dustyBox();
                        } else {
                            userInfo.broom();
                        }
                    } else if(input.equals("Refrigerator")) {
                        userInfo.fridge();
                    } else {
                        userInfo.cabinet();
                    }
                    } else {
                        userInfo.candelDR();
                    }
 } else {
     String inputUpstairs = userInfo.upStairs();
        if(inputUpstairs.equals("First Bedroom")){
            String inputBedOne = userInfo.firstBR();
                if(inputBedOne.equals("Rocking Chair")){
                    userInfo.chair();
                } else if(inputBedOne.equals("Window")){
                    userInfo.window();
                }else {
                  int userSelectioni  = userInfo.bathroom();
                    if(userSelectioni == 0){
                        userInfo.showerFO();
                    } else {
                        userInfo.mirrorFO();
                    }
                }
    } else if(inputUpstairs.equals("Second Bedroom")) {
            String inputBedTwo = userInfo.secondBR();
                if(inputBedTwo.equals("Doll House")){
                    userInfo.dollHouse();
                } else if(inputBedTwo.equals("Dresser")){
                    userInfo.dresser();
                }else {
                  int userSelectioni  = userInfo.bathroom();
                    if(userSelectioni == 0){
                        userInfo.showerFO();
                    } else {
                        userInfo.mirrorFO();
                    }
                }
    } else {
           int userSelectioniii  = userInfo.mBed();
                    if(userSelectioniii == 0){
                        userInfo.box();
                    } else {
                       int userSelectioniiii = userInfo.mBath();
                       if(userSelectioniiii == 0){
                           userInfo.oil();
                       } else{
                          userInfo.mShower(); 
                       }
                        
                    }
    }
 
 
    }
    }
}
    

    

