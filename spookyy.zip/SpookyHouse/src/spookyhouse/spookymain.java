
package spookyhouse;
import javax.swing.JOptionPane;
import javax.swing.ImageIcon;
/**
 *
 * @author vrtaylor
 */
public class spookymain {
    public String item;
    public String icon;
    private String name;
    private String backpack;
    private int userSelection;
    private int userSelectioni;
    private int userSelectionii;
    private int userSelectioniii;
    private int userSelectioniiii;
    
    public void setUserName(String setUsersName) {
            name = setUsersName;
    }
    public String getName(){
        return name;
    }
    

    public String frontDoor(){
    ImageIcon frontDoorIcon = new ImageIcon("spookydoor.jpg");
    String[] choices = {"Living Room", "Dining Room", "Up the Stairs"};
    String input = (String) JOptionPane.showInputDialog(null, "Which room "
    + "would you like to go in, " + name + "?", "The Front Door", 
    JOptionPane.QUESTION_MESSAGE, frontDoorIcon, choices,choices[0]);
    return input;
    }
    
    public int livingRoom(){
        item = "Chest";
        icon = "The Living Room";
        ImageIcon livingRoomIcon = new ImageIcon("spookylivingroom.jpg",icon);
        
        String[] choices = {"Bathroom","Chest"};
        userSelection = JOptionPane.showOptionDialog(null, "Will you explore "
        + "the bathroom or pick up the chest, " + name + "?","The Living Room", 
        JOptionPane.DEFAULT_OPTION, JOptionPane.PLAIN_MESSAGE, livingRoomIcon, 
        choices, choices[0]);
        return userSelection;
    }
    
    public int bathroom(){
        item = "Shower";
        item = "Mirror";
        icon = "The Bathroom";
        ImageIcon bathroomIcon = new ImageIcon("br.jpg");
        
        String[] choices = {"Shower","Mirror"};
        userSelectioni = JOptionPane.showOptionDialog(null, "The door closes"
        + " behind you. You see that you can interact with the mirror and "
        + "shower. Which one will it be, " + name + "?","The Bathroom", 
        JOptionPane.DEFAULT_OPTION, JOptionPane.PLAIN_MESSAGE, bathroomIcon, 
        choices, choices[0]);
        return userSelectioni;
    }
    public String showerFO() {
        item = "Shower";
        icon = "The Bathroom";
        ImageIcon showerFO = new ImageIcon("showerone.jpg");
        
        JOptionPane.showMessageDialog(null,"You get extremely sweaty from "
                + "nerves. Lucky for you, there's a shower.\nUnsightly, but "
                + "still usable. You decide to take a shower.\nIt only has "
                + "cold "
                + "water. Gross. Wait... Is that steam? \nThe steam gets so "
                + "bad "
                + "you can't even see. \nYou panic and hurry to put on your "
                + "clothes, but it's too late. You feel hands start to trace "
                + "the back of your neck. \n\nBut you came in alone..."
        , item, userSelection, showerFO);
        
        endGame();
        return null;
    }
   public String mirrorFO() {
        item = "Mirror";
        icon = "The Bathroom";
        ImageIcon mirrorFO = new ImageIcon("mirrorone.jpg");
        
        JOptionPane.showMessageDialog(null,"After having the door close on you,"
                + " you try \nto take a breath and look in the mirror. How did "
                + "you get into this mess?\nYou start analyzing the minor "
                + "blemishes on your skin to calm\ndown from your panic. "
                + "You notice they're a bit more red than usual.\nThey"
                + " are dripping blood.\nThat's not you in the mirror, is it " 
                + name + "?\nThe bloody face looks back at you."
        , item, userSelection, mirrorFO);
        
        endGame();
        return null;
    }
    public String chestLR() {
        item = "Chest";
        icon = "The Living Room";
        ImageIcon chestLR = new ImageIcon("chest.jpg");
        
        JOptionPane.showMessageDialog(null,"You were poking around in the "
        + "chest when you felt a breeze about your neck. You turn around. No "
        + "one was there. You turn back to your chest.\nA ghost with no"
        + "face popped out. You felt such a scare your heart stopped."
        , item, userSelection, chestLR);
        
        endGame();
        return null;
    }
    
    public int diningRoom(){
        item = "Candelabra";
        icon = "The Dining Room";
        ImageIcon diningRoomIcon = new ImageIcon("diningroom.jpg");
        
        String[] choices = {"Kitchen","Candelabra"};
        userSelection = JOptionPane.showOptionDialog(null, "Will you explore "+
        "the kitchen or pick up the candelabra, " + name + "?",null, 
        JOptionPane.DEFAULT_OPTION, JOptionPane.PLAIN_MESSAGE, diningRoomIcon, 
        choices, choices[0]);
        return userSelection;
    }
   public String kitchen(){
    ImageIcon kitchen = new ImageIcon("kitchen.jpg");
    String[] choices = {"Pantry", "Refrigerator", "Cabinet"};
    String input = (String) JOptionPane.showInputDialog(null, "Would you like "
    + "to go in the pantry, refrigerator, or cabinet " + name + "?",
    "The Front Door",JOptionPane.QUESTION_MESSAGE, kitchen, choices,
    choices[0]);
    return input;
    } 
   public String fridge() {
        item = "Refrigerator";
        icon = "The Kitchen";
        ImageIcon fridge = new ImageIcon("fridge.jpg");
        
        JOptionPane.showMessageDialog(null,"You tried to open the fridge.\n"
                + "You were truly curious about how rancid the food must be.\n"
                + "Wait... This food is actually good.\n You dig into it.\n"
                + "Suddenly you don't feel so well.\nNow you know why the "
                + "ghosts around here call it soul food.", item, userSelection,
                fridge);
        
        endGame();
        return null;
    }
   public String cabinet() {
        item = "Cabinet";
        icon = "The Kitchen";
        ImageIcon cab = new ImageIcon("cab.jpg");
        
        JOptionPane.showMessageDialog(null,"Oh, cool. Cabinets. You walk over "
                + "to open them.\nAs soon as you touch them, plates and bowls "
                + "start flying out.\n You try to dodge them, but they came too"
                + " fast.\nYou're cowering and feel blood trickle down your "
                + "face.\nYou were hit in the head. You see a light..."
        , item, userSelection, cab);
        
        endGame();
        return null;
    }
   
    public String candelDR() {
        item = "Candelabra";
        icon = "The Dining Room";
        ImageIcon candelDR = new ImageIcon("candel.jpg");
        
        JOptionPane.showMessageDialog(null,"You spot a beautiful candelabra on "
                + "the dining room table. \nYou expected to use this backpack "
                + "for haunted relics, not beautiful silver candelabras!\nYou "
                + "walk towards the candelabra and you can't believe your eyes."
                + "\nOne by one, each candle lit itself.\nYou see a shadow"
                + " looming over the candles.\n\nLooks like you're not getting "
                + "it after all.", item, userSelection, candelDR);
        
        endGame();
        return null;
    }
     public int pantry(){
        ImageIcon pantry = new ImageIcon("pantry.jpg");
        
        String[] choices = {"Dusty Recipe Box","Broom"};
        userSelectionii = JOptionPane.showOptionDialog(null, "The door shuts "
                + "behind you, " + name + ".\nNo point in trying to get out.\n"
                + "Will you pick up the dusty recipe box or the broom?",null, 
        JOptionPane.DEFAULT_OPTION, JOptionPane.PLAIN_MESSAGE, pantry, 
        choices, choices[0]);
        return userSelectionii;
    }
     public String dustyBox() {
        item = "Dusty Recipe Box";
        icon = "The Pantry";
        ImageIcon cake = new ImageIcon("cake.jpg");
        
        JOptionPane.showMessageDialog(null,"The box of cake mix is the only "
                + "eye-catching thing here.\nYou open it and a recipe of d"
                + "evil's food cake pops out.\nHm... that can't be a good "
                + "sign.", item, userSelectionii, cake);
        
        endGame();
        return null;
    }
     public String broom() {
        item = "Broom";
        icon = "The Pantry";
        ImageIcon broom = new ImageIcon("broom.jpg");
        
        JOptionPane.showMessageDialog(null,"The entire pantry is dusty. So,"
                + " you decide to sweep.\nThere is a convenient broom.\nYou "
                + "touch it and it flies away.\nWell. There goes your chances "
                + "of dying alone in a clean pantry.", item, userSelectionii,
                broom);
        
        endGame();
        return null;
    }
    public String upStairs(){
    ImageIcon upstairsIcon = new ImageIcon("upstairs.jpg");
    String[] choices = {"First Bedroom", "Second Bedroom", "Master Bedroom"};
    String inputUpstairs = (String) JOptionPane.showInputDialog(null, "Now "
    + "that we're on the second floor, there's no turning back. Which room "
    + "would you like to go in, " + name + "?", "The Top of the Stairs", 
    JOptionPane.QUESTION_MESSAGE, upstairsIcon, choices,choices[0]);
    return inputUpstairs;
    }
    public String firstBR(){
    ImageIcon bed = new ImageIcon("bedone.jpg");
    String[] choices = {"Rocking Chair", "Window", "Bathroom"};
    String inputBedOne = (String) JOptionPane.showInputDialog(null, "You can "
            + "either play with the rocking chair, look out the window, or "
            + "go into the bathroom.\nWhat would you like to do, " + name + "?"
            , "The First Bedroom", 
    JOptionPane.QUESTION_MESSAGE, bed, choices,choices[0]);
    return inputBedOne;
    }
    public String chair() {
        item = "Rocking Chair";
        icon = "The First Bedroom";
        ImageIcon chair = new ImageIcon("chair.jpg");
        
        JOptionPane.showMessageDialog(null,"You find a lovely place to sit.\n"
                + "You approach the chair and it starts rocking by itself.\n"
                + "Nevermind...", item, userSelectioniii,
                chair);
        
        endGame();
        return null;
    }
    public String window() {
        item = "Window";
        icon = "The First Bedroom";
        ImageIcon window = new ImageIcon("window.jpg");
        
        JOptionPane.showMessageDialog(null,"You get bored of being inside.\n"
                + "This place isn't super creepy.\nYou look out the window for"
                + " stimulation.\nWas that child swinging on the swings before"
                + " you walked in? Weird.\nYou look away for a second and when"
                + " you look back he's gone...", item, userSelectioniii,
                window);
        
        endGame();
        return null;
    }
    public String secondBR(){
    ImageIcon bedT = new ImageIcon("bedtwo.jpg");
    String[] choices = {"Doll House", "Dresser", "Bathroom"};
    String inputBedOne = (String) JOptionPane.showInputDialog(null, "You can "
            + "either play with the doll house, look at the dresser, or "
            + "go into the bathroom.\nWhat would you like to do, " + name + "?"
            , "The Second Bedroom", 
    JOptionPane.QUESTION_MESSAGE, bedT, choices,choices[0]);
    return inputBedOne;
    }
    public String dollHouse() {
        item = "Doll House";
        icon = "The Second Bedroom";
        ImageIcon doll = new ImageIcon("doll.jpg");
        
        JOptionPane.showMessageDialog(null,"It wasn't even a second that you "
                + "started playing with it that the dolls just got up\nand"
                + " started dancing. What are you looking at?\nJust a couple of"
                + " dolls gone wild.", item, userSelectioniii,
                doll);
        
        endGame();
        return null;
    }
    public String dresser() {
        item = "Dresser";
        icon = "The Second Bedroom";
        ImageIcon dresser = new ImageIcon("dress.jpg");
        
        JOptionPane.showMessageDialog(null,"You open the dresser and a ghost "
                + "flies out and goes through your body.\n Needless to say..."
                + " you'll probably be joining him soon.", item, 
                userSelectioniii,dresser);
        
        endGame();
        return null;
    }
    public int mBed(){
        ImageIcon mbed = new ImageIcon("mbed.jpg");
        
        String[] choices = {"Jewelry Box","Master Bathroom"};
        userSelectioniii = JOptionPane.showOptionDialog(null, "The door shuts "
                + "behind you, " + name + ".\nYou can't get out.\n"
                + "Will you pick up jewelry box or head to the master "
                + "bathroom?",null, 
        JOptionPane.DEFAULT_OPTION, JOptionPane.PLAIN_MESSAGE, mbed, 
        choices, choices[0]);
        return userSelectioniii;
    }
   public String box() {
        item = "Jewelry Box";
        icon = "The Master Bedroom";
        ImageIcon box = new ImageIcon("box.jpg");
        
        JOptionPane.showMessageDialog(null,"Wait a second... This is the "
                + "diamond your local news was talking about.\nThe Hope "
                + "Diamond "
                + "has a generational curse on it.\nYou wish you hadn't opened "
                + "the box.\nYou feel impending doom...", item, 
                userSelectioniii,box);
        
        endGame();
        return null;
    } 
   public int mBath(){
        ImageIcon mbath = new ImageIcon("mbath.jpg");
        
        String[] choices = {"Intricate Oil Lamp","Shower"};
        userSelectioniiii = JOptionPane.showOptionDialog(null, "The door shuts "
                + "behind you, " + name + ".\nYou can't escape again.\n"
                + "Will you pick up the intricate oil lamp or take a shower"
                + " to clear your mind?",null, 
        JOptionPane.DEFAULT_OPTION, JOptionPane.PLAIN_MESSAGE, mbath, 
        choices, choices[0]);
        return userSelectioniiii;
    } 
   public String oil() {
        item = "Intricate Oil Lamp";
        icon = "The Master Bathroom";
        ImageIcon oil = new ImageIcon("oil.jpg");
        
        JOptionPane.showMessageDialog(null,"You know what? You might as well.\n"
                + "You grab the lamp and rub it.\nA genie comes out and "
                + "actually"
                + " grants you wishes. Shocking. He seems like he may be "
                + "lying.", item, 
                userSelectioniiii,oil);
        
        endGame();
        return null;
    } 
   public String mShower() {
        item = "Shower";
        icon = "The Master Bathroom";
        ImageIcon mshower = new ImageIcon("showertwo.jpg");
        
        JOptionPane.showMessageDialog(null,"You jump in the nasty shower to "
                + "clear your mind.\nYou start singing to yourself.\nYou felt"
                + " like you were in Elf because you heard someone else "
                + "start singing.\nYou open the shower curtain in panic...\n\n"
                + "No one is there.", item, 
                userSelectioniiii,mshower);
        
        endGame();
        return null;
    } 
public String endGame(){
    
    ImageIcon gameOver = new ImageIcon("endgame.jpg");
    JOptionPane.showMessageDialog(null,"Game over, " + name+
    ".\n\n YOU COLLECTED: " + backpack() + "!\nYOUR LAST ROOM: " 
            + deathLocation() + "!", item, userSelection, gameOver);
    
    return null;
}
public String backpack(){
return this.item;
}
public String deathLocation(){
    return this.icon;
}    


}